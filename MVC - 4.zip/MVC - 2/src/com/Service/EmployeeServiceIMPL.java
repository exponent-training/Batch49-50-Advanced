package com.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.EmployeeDAO;
import com.Entity.Employee;

@Service
public class EmployeeServiceIMPL implements EmployeeService {

	@Autowired
	private EmployeeDAO ed;

	@Override
	public void registerEmployeeInService(Employee emp) {

		System.out.println("I am in Service Layer");

		ed.RegisterEmployeeInDAO(emp);

	}

}
