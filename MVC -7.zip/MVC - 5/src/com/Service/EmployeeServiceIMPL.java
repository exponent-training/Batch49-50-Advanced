package com.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.EmployeeDAO;
import com.Entity.Employee;

@Service
public class EmployeeServiceIMPL implements EmployeeService {

	@Autowired
	private EmployeeDAO ed;

	@Override
	public void registerEmployeeInService(Employee emp) {

		System.out.println("I am in Service Layer");

		ed.RegisterEmployeeInDAO(emp);

	}

	@Override
	public List<Employee> getAllEMployees() {

		return ed.getAllEmployeesInDAO();
	}

	@Override
	public List<Employee> deleteEMployeeInService(int id) {
		
		return  ed.deleteEmployeeInDao(id);
		
	}

	@Override
	public Employee editEmployeeInService(int id) {
		
		return ed.editEmployeeInDao(id);
		
	}

	@Override
	public List<Employee> updateEmpployeeInService(Employee emp) {
		
		return ed.updateEmployeeInDao(emp);
		
	}

}
