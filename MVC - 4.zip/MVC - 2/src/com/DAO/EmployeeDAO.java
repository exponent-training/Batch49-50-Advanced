package com.DAO;

import com.Entity.Employee;

public interface EmployeeDAO {

	public void RegisterEmployeeInDAO(Employee emp);

}
