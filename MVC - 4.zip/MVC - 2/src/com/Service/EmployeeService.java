package com.Service;

import com.Entity.Employee;

public interface EmployeeService {

	public void registerEmployeeInService(Employee emp);

}
