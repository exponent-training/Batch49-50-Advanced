package com;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.Employee;
import com.Service.EmployeeService;

@Controller
public class HomeController {

	// 100
	// reg

	@Autowired
	private EmployeeService es;

	private static final String username = "admin";
	private static final String password = "admin123";

	@RequestMapping(value = "/reg")
	public String getRegusterRequest(@ModelAttribute Employee emp) {
		System.out.println("I am in Controller");

		es.registerEmployeeInService(emp);

		return "success";
	}

	@RequestMapping(value = "/log")
	public String loginEmployee(@RequestParam("username") String un, @RequestParam("password") String ps, Model model) {

		if (username.equals(un) && password.equals(ps)) {
			List<Employee> employees = es.getAllEMployees();
			System.out.println(employees);

			model.addAttribute("msg", employees);

			return "success";

		} else {

			model.addAttribute("msg", "Invalid Username and password!!!");
			return "login";

		}

	}

}
