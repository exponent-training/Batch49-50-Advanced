package com.DAO;

import java.util.List;

import com.Entity.Employee;

public interface EmployeeDAO {

	public void RegisterEmployeeInDAO(Employee emp);
	
	public List<Employee> getAllEmployeesInDAO();

}
