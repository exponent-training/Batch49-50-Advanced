package com;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	// 100
	// reg

	@RequestMapping(value = "/reg")
	public String getRegusterRequest() {
		System.out.println("I am in Controller your reg request is here");
		
		return  "success";
	}

}
