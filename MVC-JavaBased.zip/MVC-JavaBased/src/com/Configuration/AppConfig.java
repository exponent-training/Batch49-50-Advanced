package com.Configuration;

import java.util.Properties;

import org.gjt.mm.mysql.Driver;
import org.hibernate.cfg.Environment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.Entity.Student;

@Configuration
@ComponentScan(basePackages = "com")
@EnableWebMvc
public class AppConfig {

	@Bean
	public InternalResourceViewResolver view() {
		InternalResourceViewResolver irv = new InternalResourceViewResolver();
		irv.setSuffix(".jsp");

		return irv;

	}

	@Bean
	public DriverManagerDataSource dataSource() {
		DriverManagerDataSource dmd = new DriverManagerDataSource();
		dmd.setDriverClassName("com.mysql.jdbc.Driver");
		dmd.setUrl("jdbc:mysql://localhost:3306/batch4950");
		dmd.setUsername("root");
		dmd.setPassword("root");

		return dmd;
	}

	@Bean
	public LocalSessionFactoryBean allprops() {
		LocalSessionFactoryBean lsfb = new LocalSessionFactoryBean();

		lsfb.setDataSource(dataSource());

		Properties props = new Properties();
		props.setProperty(Environment.DIALECT, "org.hibernate.dialect.MySQLDialect");
		props.setProperty(Environment.HBM2DDL_AUTO, "update");
		props.setProperty(Environment.SHOW_SQL, "true");

		lsfb.setHibernateProperties(props);

		lsfb.setAnnotatedClasses(Student.class);

		return lsfb;

	}
}
