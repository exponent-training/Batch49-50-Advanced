package com.Service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.Entity.Employee;

public interface EmployeeService {

	public void registerEmployeeInService(Employee emp);

	public List<Employee> getAllEMployees();

	public List<Employee> deleteEMployeeInService(int id);

	public Employee editEmployeeInService(int id);

	public List<Employee> updateEmpployeeInService(Employee emp);

	public void uploadFileInService(MultipartFile file);

}
