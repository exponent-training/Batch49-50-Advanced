package com;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.Employee;
import com.Service.EmployeeService;

@Controller
public class HomeController {

	// 100
	// reg

	@Autowired
	private EmployeeService es;

	private static final String username = "admin";
	private static final String password = "admin123";

	@RequestMapping(value = "/reg")
	public String getRegusterRequest(@ModelAttribute Employee emp) {
		System.out.println("I am in Controller");

		es.registerEmployeeInService(emp);

		return "login";
	}

	@RequestMapping(value = "/log")
	public String loginEmployee(@RequestParam("username") String un, @RequestParam("password") String ps, Model model) {

		if (username.equals(un) && password.equals(ps)) {
			List<Employee> employees = es.getAllEMployees();
			System.out.println(employees);

			model.addAttribute("msg", employees);

			return "success";

		} else {

			model.addAttribute("msg", "Invalid Username and password!!!");
			return "login";

		}

	}

	@RequestMapping(value = "/del")
	public String deleteEMployee(@RequestParam("eid") int id, Model model) {
		List<Employee> le = es.deleteEMployeeInService(id);
		if (le != null) {
			model.addAttribute("msg", le);
			return "success";
		}

		return "login";

	}

	@RequestMapping(value = "/edit")
	public String editEmployee(@RequestParam("eid") int id, Model model) {

		Employee employee = es.editEmployeeInService(id);

		if (employee != null) {
			model.addAttribute("msg", employee);

			return "update";
		}

		return "login";

	}

	@RequestMapping(value = "/up")
	public String updateEmployee(@ModelAttribute Employee emp, Model model) {
		List<Employee> listemp = es.updateEmpployeeInService(emp);

		if (listemp != null) {
			model.addAttribute("msg", listemp);

			return "success";
		}
		return "login";
	}

}
