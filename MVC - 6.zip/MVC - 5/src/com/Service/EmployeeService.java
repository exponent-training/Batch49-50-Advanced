package com.Service;

import java.util.List;

import com.Entity.Employee;

public interface EmployeeService {

	public void registerEmployeeInService(Employee emp);

	public List<Employee> getAllEMployees();

	public List<Employee> deleteEMployeeInService(int id);

}
