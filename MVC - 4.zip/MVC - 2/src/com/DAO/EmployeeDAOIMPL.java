package com.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.Employee;

@Repository
public class EmployeeDAOIMPL implements EmployeeDAO {

	@Autowired
	private SessionFactory sf;

	@Override
	public void RegisterEmployeeInDAO(Employee emp) {

		System.out.println("I am in DAO layer");

		Session s = sf.openSession();

		s.save(emp);

		s.beginTransaction().commit();
		System.out.println("Employee registerd");
	}

}
