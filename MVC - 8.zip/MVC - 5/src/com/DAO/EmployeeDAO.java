package com.DAO;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.Entity.Employee;

public interface EmployeeDAO {

	public void RegisterEmployeeInDAO(Employee emp);
	
	public List<Employee> getAllEmployeesInDAO();

	public List<Employee> deleteEmployeeInDao(int id);

	public Employee editEmployeeInDao(int id);

	public List<Employee> updateEmployeeInDao(Employee emp);

	public void uploadFileInDao(MultipartFile file);

}
