package com.Controller;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Entity.Student;

@Controller
public class Homecontroller {

	@Autowired
	private SessionFactory sf;

	@RequestMapping(value = "/log")
	public String getMsg() {
		return "success";
	}

	@RequestMapping(value = "/reg")
	public String registerStudent(@ModelAttribute Student st) {

		Session se = sf.openSession();

		se.save(st);

		se.beginTransaction().commit();
		System.out.println("Student registerd");

		return "success";
	}

}
