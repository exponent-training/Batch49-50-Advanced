package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.Entity.Employee;
import com.Service.EmployeeService;

@Controller
public class HomeController {

	// 100
	// reg

	@Autowired
	private EmployeeService es;

	@RequestMapping(value = "/reg")
	public String getRegusterRequest(@ModelAttribute Employee emp) {
		System.out.println("I am in Controller");
		
		es.registerEmployeeInService(emp);

		return "success";
	}

}
