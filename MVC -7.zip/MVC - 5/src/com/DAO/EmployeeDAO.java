package com.DAO;

import java.util.List;

import com.Entity.Employee;

public interface EmployeeDAO {

	public void RegisterEmployeeInDAO(Employee emp);
	
	public List<Employee> getAllEmployeesInDAO();

	public List<Employee> deleteEmployeeInDao(int id);

	public Employee editEmployeeInDao(int id);

	public List<Employee> updateEmployeeInDao(Employee emp);

}
