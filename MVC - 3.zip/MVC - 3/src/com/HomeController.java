package com;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.Student;

@Controller
public class HomeController {

	// 100
	// reg

	static List<Student> st = new ArrayList<Student>();

//	@RequestMapping(value = "/reg")
//	public String getRegusterRequest(@RequestParam("uname") String un, @RequestParam("username") String usern,
//			@RequestParam("password") String ps) {
//
//		System.out.println("Username :- " + usern);
//		System.out.println("User :- " + un);
//		System.out.println("Password :- " + ps);
//		System.out.println("I am in Controller your reg request is here");
//
//		return "success";
//	}

	@RequestMapping(value = "/reg")
	public String getRegusterRequest(@ModelAttribute Student st) {

//		System.out.println("Username :- " + usern);
//		System.out.println("User :- " + un);
//		System.out.println("Password :- " + ps);

		System.out.println(st);
		System.out.println("I am in Controller your reg request is here");

		return "success";
	}

}
