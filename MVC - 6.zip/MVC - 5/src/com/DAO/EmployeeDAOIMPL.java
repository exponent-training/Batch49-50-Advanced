package com.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.Employee;

@Repository
public class EmployeeDAOIMPL implements EmployeeDAO {

	@Autowired
	private SessionFactory sf;

	@Override
	public void RegisterEmployeeInDAO(Employee emp) {

		System.out.println("I am in DAO layer");

		Session s = sf.openSession();

		s.save(emp);

		s.beginTransaction().commit();
		System.out.println("Employee registerd");
	}

	@Override
	public List<Employee> getAllEmployeesInDAO() {

		Session s = sf.openSession();
		Query query = s.createQuery("from Employee");
		List employees = query.getResultList();

		return employees;
	}

	@Override
	public List<Employee> deleteEmployeeInDao(int id) {

		Session s = sf.openSession();
		Employee employee = s.get(Employee.class, id);
		if (employee != null) {

			s.delete(employee);
			s.beginTransaction().commit();
			System.out.println("Employee deledted");

		}

		Query query = s.createQuery("from Employee");
		List employees = query.getResultList();

		return employees;

	}

}
